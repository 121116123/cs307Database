public class signinGUI {
    public signinGUI(firstGUI firstGUI) {
    }//登陆界面

    public void setVisible(boolean visible) {
        this.setVisible(true);
    }
}
