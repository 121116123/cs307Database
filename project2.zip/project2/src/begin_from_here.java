public class begin_from_here {
    public static void main(String[] args) {

    }
}
