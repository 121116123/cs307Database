public class post_category {
    private int postid;
    private String category;

    public int getPostid() {
        return postid;
    }

    public String getCategory() {
        return category;
    }

    public void setPostid(int postid) {
        this.postid = postid;
    }

    public void setCategory(String category) {
        this.category = category;
    }
}
