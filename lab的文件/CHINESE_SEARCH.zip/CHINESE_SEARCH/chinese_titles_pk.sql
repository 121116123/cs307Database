alter table chinese_titles
add constraint chinese_titles_pk primary key (movieid, rn);
