select movieid, chinese_split(title) from chinese_titles 
;
